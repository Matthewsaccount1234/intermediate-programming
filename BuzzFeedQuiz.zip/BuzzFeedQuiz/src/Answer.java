/*
 * Irene Feng 10/12/2022
 * This is an answer with a Category it corresponds to
 */

public class Answer {
    String label;
    Category cat;
    
    // Constructor
    Answer(String label, Category c) {
        this.label = label; 
        this.cat = c;
    }
}
